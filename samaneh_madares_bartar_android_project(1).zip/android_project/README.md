# سامانه مدارس برتر - Android

این پروژه نسخه HTML سامانه را در یک Android WebView اجرا می‌کند.

## ساخت APK با GitHub Actions
1. تمام محتویات این پوشه را در ریشه مخزن GitHub بارگذاری کنید (خود پوشه android_project را به عنوان یک پوشه تو در تو قرار ندهید).
2. تغییرات را با Commit changes ثبت کنید.
3. از زبانه Actions، گردش کار Build Android APK را اجرا کنید؛ با push به شاخه main نیز خودکار اجرا می‌شود.
4. پس از موفقیت، در صفحه اجرای workflow بخش Artifacts فایل `samaneh-madares-bartar-apk` را دانلود کنید.

APK خروجی از نوع debug است و برای نصب آزمایشی مناسب است.
